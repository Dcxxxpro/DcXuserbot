#!/usr/bin/env bash
set -e

echo "=========================================================="
echo "    🦁 LionX Userbot - AWS EC2 Deploy & Setup Engine     "
echo "=========================================================="

# 1. Update OS and install system dependencies
echo ">>> [1/5] Updating packages & installing system libraries..."
sudo apt-get update -y
sudo apt-get install -y python3 python3-pip python3-venv git curl ffmpeg libjpeg-dev zlib1g-dev libffi-dev libpq-dev mediainfo

# 2. Setup 2GB Swap Memory (Crucial for t2.micro & t3.micro EC2 free tier)
if [ ! -f /swapfile ]; then
    echo ">>> [2/5] Creating 2GB swap space for t2.micro stability..."
    sudo fallocate -l 2G /swapfile || sudo dd if=/dev/zero of=/swapfile bs=1M count=2048
    sudo chmod 600 /swapfile
    sudo mkswap /swapfile
    sudo swapon /swapfile
    echo "/swapfile none swap sw 0 0" | sudo tee -a /etc/fstab
fi

# 3. Create Python Virtual Environment
echo ">>> [3/5] Setting up virtual environment..."
cd "$(dirname "$0")"
if [ ! -d "venv" ]; then
    python3 -m venv venv
fi
source venv/bin/activate

# 4. Install Python requirements
echo ">>> [4/5] Installing dependencies from requirements.txt..."
pip install --upgrade pip setuptools wheel
pip install -r requirements.txt

# 5. Setup Systemd Service for 24/7 background operation
BOT_DIR=$(pwd)
CURRENT_USER=$(whoami)

echo ">>> [5/5] Configuring systemd background daemon (lionx.service)..."
sudo bash -c "cat <<EOF > /etc/systemd/system/lionx.service
[Unit]
Description=LionX Userbot 24/7 Daemon
After=network.target

[Service]
Type=simple
User=${CURRENT_USER}
WorkingDirectory=${BOT_DIR}
ExecStart=${BOT_DIR}/venv/bin/python3 -m userbot
Restart=always
RestartSec=5
EnvironmentFile=${BOT_DIR}/.env

[Install]
WantedBy=multi-user.target
EOF"

sudo systemctl daemon-reload
sudo systemctl enable lionx.service

echo ""
echo "=========================================================="
echo "  🎉 LionX is now ready for deployment!"
echo "  1. Edit .env with your Telegram credentials:"
echo "     nano .env"
echo "  2. Start the userbot service:"
echo "     sudo systemctl start lionx"
echo "  3. View live logs anytime:"
echo "     sudo journalctl -u lionx -f"
echo "=========================================================="
